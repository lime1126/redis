Converted for Minecraft Java 26.2.
Resource Pack Version: 88.0
Adds modern assets/minecraft/items/*.json item definitions while preserving the original 3D sword models/textures.
This pack replaces the vanilla wooden, stone, iron, golden, diamond, and netherite sword appearances.
