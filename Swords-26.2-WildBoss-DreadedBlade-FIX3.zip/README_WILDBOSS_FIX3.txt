WildBoss Dreaded Blade fix 3: vanilla minecraft namespace + corrected 32x32 Blockbench UV to 16x16 Java model UV. IRON_SWORD CMD float index 0 threshold 26001.
