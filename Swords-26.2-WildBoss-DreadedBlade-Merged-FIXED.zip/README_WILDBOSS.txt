WildBoss Dreaded Blade merge
- Existing sword models/textures are preserved.
- Netherite sword files are untouched.
- WildBoss Dreaded Blade is selected only on IRON_SWORD with CustomModelData 26001.
- WildBoss source v0.7.0 already spawns its execution/shockwave display using IRON_SWORD + CustomModelData 26001.
