WildBoss Dreaded Blade texture fix
- Added .png.mcmeta animation metadata for the 32x320 (10-frame) Blockbench textures.
- Added texture_size [32,32] to the Java model.
- Keeps IRON_SWORD CustomModelData 26001 mapping.
